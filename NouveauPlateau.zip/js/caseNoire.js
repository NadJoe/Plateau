class CaseNoire{
    // CHAQUE joueur à une image qui lui est propre donc il faut la mettre à la création de chaque objet de type joueur
    constructor (positionX, positionY){
        this.position = {x: positionX, y: positionY};
    }
}
