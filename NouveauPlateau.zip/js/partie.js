class Partie{
    constructor(plateau, armes, joueur1, joueur2){
        this._plateau = plateau;
        this._armes = this.genererArmes(armes);
        this.joueurs = [joueur1, joueur2];
        this.currentPlayer = 1;
    }

    genererArmes(armes){
        let mesArmes = [];
        armes.forEach(element => {
            let arme = new Arme(element.nom, element.degats);
            mesArmes.push(arme);
        });
        return mesArmes;
    }

    miseEnplace(){
        this._plateau.creationColonne();
        this._plateau.creationCaseGrise();
        this._plateau.creationCase('noire', 20);
        //console.log("Mise en place : ",this._armes);
        this._plateau.creationCase('arme', this._armes.length, this._armes);
        this._plateau.creationCase('joueur', this.joueurs.length, this.joueurs) 
        this.joueurs = this._plateau._joueurs;
    }

    jouer(){
        let player = this.currentPlayer === 1 ? this.joueurs[0] : this.joueurs[1];
        //this._plateau.displayCase();
        player.deplacementDisponible();
        //player.turn();


       let availableMoveCases = Array.from(document.getElementsByClassName('surbrillance'));
       console.log(availableMoveCases);
       availableMoveCases.forEach(element => {
            element.addEventListener('click', () =>{
                //alert('move');
                //console.log('cliqué', element);
                let tableau = element.id.split("-");
                //console.log("tableau", tableau);
                player.move(tableau[1], tableau[2]);
                //console.log(player);
                //console.log(this._plateau);
                this._plateau.displayCase();
                console.log(this.currentPlayer);
                this.currentPlayer = 0;
                console.log(this.currentPlayer);
            });
       });
    }
    
}